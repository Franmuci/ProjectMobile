using System.Collections;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class TransitionManager : MonoBehaviour
{

    public static TransitionManager instance;

    [SerializeField] GameObject sceneTransition;
    [SerializeField] GameObject loadingPanel;
    [SerializeField] Slider progressBar;
    SceneTransition transition;


    private void Awake()
    {
        if (instance == null)
        {
            instance = this;
            DontDestroyOnLoad(gameObject);
        }
        else
        {
            Destroy(gameObject);
        }

        transition = sceneTransition.GetComponent<SceneTransition>();
    }

    public void LoadScene(string sceneName)
    {
        StartCoroutine(LoadSceneAsync(sceneName));
    }

    private IEnumerator LoadSceneAsync(string sceneName)
    {
        AsyncOperation scene = SceneManager.LoadSceneAsync(sceneName);
        scene.allowSceneActivation = false;

        yield return transition.AnimateTransitionIn();

        loadingPanel.SetActive(true);

        do
        {
            print("hi");
            progressBar.value = scene.progress;
            yield return null;

        } while (scene.progress < 0.9f);

        yield return new WaitForSeconds(1f);

        scene.allowSceneActivation = true;

        loadingPanel.SetActive(false);

        yield return transition.AnimateTransitionOut();
    }

}
