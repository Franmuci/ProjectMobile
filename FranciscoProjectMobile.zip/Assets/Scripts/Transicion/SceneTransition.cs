using System.Collections;
using UnityEngine;
using UnityEngine.UI;
using DG.Tweening;

public class SceneTransition : MonoBehaviour
{

    [SerializeField] Image image;

    public IEnumerator AnimateTransitionIn()
    {
        image.rectTransform.anchoredPosition = new Vector2(0f, 0f);
        var tweener = image.rectTransform.DOScale(new Vector3(1f,1f,1f),1f);
        yield return tweener.WaitForCompletion();
    }

    public IEnumerator AnimateTransitionOut()
    {
        
        var tweener = image.rectTransform.DOScale(new Vector3(0f, 0f, 0f), 1f);
        yield return tweener.WaitForCompletion();
    }
}
