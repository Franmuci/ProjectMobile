using UnityEngine;

public class LevelManager : MonoBehaviour
{

    [SerializeField] GameObject firstWave;
    [SerializeField] GameObject secondWave;
    private bool isSecondWave;

    private void Start()
    {
        InvokeRepeating(nameof(Spawner), 3f,3f);
    }

    private void Spawner()
    {
        if(isSecondWave)
        {
            Instantiate(secondWave);
            isSecondWave = false;
        }
        else
        {
            Instantiate(firstWave);
            isSecondWave = true;
        }
    }
}
