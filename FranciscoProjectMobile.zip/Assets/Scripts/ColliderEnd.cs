using System.Linq;
using TMPro;
using UnityEngine;

public class ColliderEnd : MonoBehaviour
{

    [SerializeField] GameObject panelEnd;
    [SerializeField] SavePoints scriptableSavePoints;
    [SerializeField] GameObject leaderboardPanel;
    [SerializeField] GameObject submitLeaderPanel;
    [SerializeField] GameObject boardPanel;
    [SerializeField] TMP_InputField inputText;

    private void Awake()
    {
        panelEnd.SetActive(false);
    }

    private void Start()
    {
        ActualizarLeaderboard();
        submitLeaderPanel.SetActive(false);
    }

    private void ActualizarLeaderboard()
    {
        scriptableSavePoints.leaderBoard.Sort((a, b) => b.puntos.CompareTo(a.puntos));

        foreach(Transform g in leaderboardPanel.transform)
        {
            Destroy(g.gameObject);
        }

        foreach (LeaderBoard p in scriptableSavePoints.leaderBoard)
        {
            GameObject a = Instantiate(boardPanel, leaderboardPanel.transform);
            a.GetComponentInChildren<TMP_Text>().text = $"{p.nombre} - {p.puntos}";
        }
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.CompareTag("Alien"))
        {
            Time.timeScale = 0.0f;
            panelEnd.SetActive(true);
            if(scriptableSavePoints.highScore <= GameManager.Instance.totalPoints)
            {
                scriptableSavePoints.highScore = GameManager.Instance.totalPoints;
            }

            if (scriptableSavePoints.leaderBoard.Count >= 10)
            {
                if(scriptableSavePoints.leaderBoard.Min((a) => a.puntos) <= GameManager.Instance.totalPoints)
                {
                    submitLeaderPanel.SetActive(true);
                    scriptableSavePoints.leaderBoard.RemoveAt(scriptableSavePoints.leaderBoard.Count-1);
                }
            }


        }
    }

    public void AddLeaderboard()
    {
        scriptableSavePoints.leaderBoard.Add(new LeaderBoard(inputText.text, GameManager.Instance.totalPoints));
        submitLeaderPanel.SetActive(false);
        ActualizarLeaderboard();
    }
}


